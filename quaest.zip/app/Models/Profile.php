<?php

namespace App\Models;

use App\Models\Model;

class Profile extends Model
{
	public $table = 'profile';
}
