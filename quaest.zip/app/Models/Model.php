<?php

namespace App\Models;

class Model
{
	public function __construct()
	{
		// for any bootstrapping method invokes, if required.
	}
}