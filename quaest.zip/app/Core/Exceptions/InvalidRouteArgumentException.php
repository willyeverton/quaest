<?php

namespace App\Core\Exceptions;

class InvalidRouteArgumentException extends \Exception
{
	//
}