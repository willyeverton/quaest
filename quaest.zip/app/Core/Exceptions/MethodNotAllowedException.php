<?php

namespace App\Core\Exceptions;

class MethodNotAllowedException extends \Exception
{
    //
}