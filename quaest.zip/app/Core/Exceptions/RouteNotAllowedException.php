<?php

namespace App\Core\Exceptions;

class RouteNotFoundException extends \Exception
{
    //
}
