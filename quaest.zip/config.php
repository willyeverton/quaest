<?php

return [

	'database' => [
		'driver'   => 'pgsql',
		'host'     => 'ec2-107-20-104-234.compute-1.amazonaws.com',
		'database' => 'd7hohjuv5lsfsh',
		'username' => 'sfiqersvhrzady',
		'password' => '9a9343f633d284d97fe0ebf5b3c52adfc70e302b2a99ce4cd9d917c94298bd2d',
		'options' => [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]
	],

];
